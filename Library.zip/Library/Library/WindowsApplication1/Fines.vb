﻿Public Class Fines
    Dim checkOutMonth As Integer
    Dim checkOutDay As Integer
    Dim checkoutYear As Integer
    Dim monthDue As Integer
    Dim dayDue As Integer
    Dim yearDue As Integer
    Dim fine As Double

    Function mediaCheckedout() As String
        checkOutMonth = Date.Now.Month
        checkOutDay = Date.Now.Day
        checkoutYear = Date.Now.Year
        Return checkOutMonth & "/" & checkOutDay & "/" & checkoutYear
    End Function

    Function DueDate() As String
        If checkOutMonth < 12 Then
            monthDue = checkOutMonth + 1
        Else
            monthDue = 1
            yearDue = checkoutYear + 1
        End If

        If checkOutDay > 30 Then
            dayDue = 29
        Else : dayDue = checkOutDay
        End If

        Return monthDue & "/" & dayDue & "/" & yearDue
    End Function

    Function IsLate() As Boolean
        If checkOutMonth = 12 And Date.Now.Month > 1 Then
            Return True
        ElseIf monthDue > Date.Now.Month Then
            Return True
        End If
        Return False
    End Function
    Function FetFines() As Double
        Dim monthsLate As Integer = 0
        Dim daysLate As Integer = 0
        If IsLate() Then
            If monthDue < Date.Now.Month Then
                monthDue = monthDue - 12
            End If
            monthsLate = Date.Now.Month - monthDue

            If dayDue < Date.Now.Day Then
                daysLate = Date.Now.Day
            End If
            daysLate = Date.Now.Day - dayDue
        End If
        fine = monthsLate * 1.5 + daysLate * 0.05
        Return fine
    End Function
End Class
